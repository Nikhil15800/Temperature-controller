import React, { useState } from 'react';
import './App.css';

function App() {
  const [value, setvalue]= useState( 0 );
  const Increment = () =>{
    setvalue(value+1);
    if(value<=10){
      
    }
  }
  const Decrement = () =>{
    setvalue(value-1);
  }

  return (
    <>
    <div className='container'>
        <h2>Temperature Controler</h2>
        <div className='main'> 
            <p className='value'>{value}</p>
        </div>

        <div className='btn'>
            <button className='dec' onClick={Decrement} >Decrement</button>
            <button className='inc' onClick={Increment} >Increment</button>
        </div>
    </div>
    </>
  );
}

export default App;
